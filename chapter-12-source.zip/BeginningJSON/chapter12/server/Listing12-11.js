var cradle = require('../node_modules/cradle');
var DBConnection = cradle.Connection;
var couchDB = new DBConnection('127.0.0.1', 5984, {
 cache : true,
 raw : false,
 forceSave : true
});

var gbDataBase = couchDB.database('guestbook');

gbDataBase.exists(function(err, exists) {
 if (err) {
  console.log('error', err);
 } else if (exists) {
  console.log('the guestbook db exists');
 } else {
  console.log('database does not exists.');
  gbDataBase.create();
 }
});

/*obtain an existing view*/
gbDataBase.view('guests/signatures', null, function(err, res) {
 console.log(res);
});

