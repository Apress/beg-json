var cradle = require('../node_modules/cradle');

var couchDB = new (cradle.Connection)('127.0.0.1', 5984, {
 cache : true,
 raw : false,
 forceSave : true
});

var gb = couchDB.database('guestbook');
gb.create();

gb.exists(function(err, exists) {
 if (err) {
  console.log('error', err);
 } else if (exists) {
  console.log('the guestbook db exists');
 } else {
  console.log('database does not exists.');
  gb.create();
 }
});

/*obtain an existing view*/
gb.view('guests/signatures', {
 limit : 1,
 descending : true
}, function(err, res) {
 console.log(res);
});

/* save a Permenant view  */

gb.save('_design/guest', {
 views : {
  signatures : {
   map : 'function(doc) { emit(doc.handle, {"handle":doc.handle, "message":doc.message,"_id":doc._id}); }}'
  }
 }
});

gb.save({
 handle : "@waiverly",
 message : "welcome and thank you"
}, function(err, res) {
 if (!err) {
  console.log(res);
 }
});

console.log('Server running at http://127.0.0.1:8080/');
console.log('Current directory: ' + process.cwd());
