views: { 
 signatures: {
  map:'function(doc) { emit( doc.handle, {handle:doc.handle, message:doc.message, _id:doc.id}); }';
 }
};