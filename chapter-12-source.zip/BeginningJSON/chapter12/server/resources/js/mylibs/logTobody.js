//obtain a reference to the body tag

//function log will append a value to the body for output

window.log = function() {

    log.history = log.history || [];
    // store logs to an array for reference
    log.history.push(arguments);
    if (this.console) {
        console.log(Array.prototype.slice.call(arguments));
    }

};
window.logAsIs=function(arg){
   logAsJSONtext(arg,false);
};
window.logAsJSONtext = function(arg, bool) {
    var body = document.getElementsByTagName("pre")[0];
    //wrap all strings with double quotes and append a new line
    if (!bool) {
        body.innerHTML += arg + '<br>';
    } else {
        if (arg.charAt(0) === "\"") {
            body.innerHTML += arg + '<br>';
        } else {
            body.innerHTML += '\'' + arg + '\'<br>';
        }
    }
    log(arg);
};
window.logAsString = function(arg) {
   logAsJSONtext(arg,true);
};
window.logAsObject = function(arg) {
    var body = document.getElementsByTagName("pre")[0];
    //wrap all strings with double quotes and append a new line
    body.innerHTML += stringify(arg) + '<br>';
    log(arg);
};

function stringify(structure) {
    
    if(typeof structure =="number"){
        
        return String(structure);
    }
    if(typeof structure == 'function'){
       return undefined; 
    }

    //if the structure supplied possesses the string data type
    if ( typeof structure == "string") {
        return '"' + String(structure) + '"';
    }
    
    if (Object.prototype.toString.apply(structure) === '[object Array]') {
        var partial = [];
// The value is an array. Stringify every element. Use null as a placeholder
// for non-JSON values.

         length = structure.length;
         for (i = 0; i < length; i += 1) {
             partial[i] = stringify( structure[i]) || 'null';
          }
            //if partial does not possess children capture opening/closing brackets;
        v = (partial.length === 0) ? '[]'
        //otherwise, comma delimit all values within opening/closing brackets
        : ' [ ' + partial.join(' , ') + ' ] ';
        return v;
        
    }
    //if the structure supplied possess the object data type
    if ( typeof structure == "object") {
        var partial = [];
        //for each property held by our structure
        for (var k in structure) {
            var v = structure[k];
            v = stringify(v);
            if(v===undefined){
                delete structure[k];
            }else{
            partial.push(k + " : " + v);
            }
        }
        //if partial does not possess children capture opening/closing brackets;
        v = (partial.length === 0) ? '{}'
        //otherwise, comma delimit all values within opening/closing brackets
        : ' { ' + partial.join(' , ') + ' } ';
        return v;
    }
}

