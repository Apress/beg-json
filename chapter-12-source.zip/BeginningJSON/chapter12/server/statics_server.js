var http = require('http');
var fs = require("fs");
var path = require("path");

var server = http.createServer();
server.addListener("request", requestHandler);
server.listen(8080, '127.0.0.1');

function requestHandler(request, response) {

    var DocumentRoot = "resources";
    var fullURL = request.url;
    var uri = (fullURL).match(/[^?|:]*/)[0];
    var queryIndex = (fullURL).indexOf("?");
    var queryString = (queryIndex > -1) ? parseQueryStringToObject(fullURL.substring(queryIndex + 1)) : {};

    getFile(uri);

    function getFile(fileName, statusCode) {

        var filename = fullSystemFile(fileName);

        fs.exists(filename, function(exists) {
            if (!exists) {
                return getFile("404.html", 404);
            }

            if (fs.statSync(filename).isDirectory()) {
                filename += '/index.html';
            }
            var extension = fileName.substr(fileName.indexOf(".") + 1);
            var mime = contentType(extension);
            fs.readFile(filename, "binary", function(err, file) {
                if (err) {
                    return getFile("500.html", 500);
                }

                if (mime) {
                    response.setHeader("Content-Type", mime);
                }
                if (statusCode) {
                    response.statusCode = statusCode;
                } else {
                    response.statusCode = 200;
                }
                response.write(file, "binary");
                response.end();
            });
        });
    }

    function fullSystemFile(file) {
        return path.join(process.cwd(), DocumentRoot, file);
    };

    function contentType(extension) {
        switch(extension) {
        case 'json':
            return 'application/json';
        case 'css':
            return 'text/css';
        case 'js':
            return 'application/x-javascript';
        case 'txt':
            return 'text/plain';
        case 'html':
            return 'text/html';
        case 'jpg':
            return 'image/jpeg';
        default :
            return null;
        }
    }

};

console.log('Server running at http://127.0.0.1:8080/');
console.log('Current directory: ' + process.cwd());
