var cradle = require('../node_modules/cradle');
var DBConnection = cradle.Connection;
var couchDB = new DBConnection('127.0.0.1', 5984, {
 cache : true,
 raw : false,
 forceSave : true
});

var gbDataBase = couchDB.database('guestbook');
gbDataBase.create();
