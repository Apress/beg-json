someMethod({
"name":"Ben",
"age" :"36",
"cats":[{ "name":"waverly","age":4},{"name":"westley","age":4.5}],
"ssnumber":"xxxxxxxxx",
"address":"xxx xxxxxxxxxx",
"zip":"xxxxxxx"
});
