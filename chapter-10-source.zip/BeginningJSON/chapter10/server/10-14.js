var http = require('http');

var options = {
 hostname : "json.sandboxed.guru",
 path : '/chapter10/data/imagedata.txt',
 method : "GET"
};

var clientRequest = http.request(options, responseHandler);
clientRequest.end();
function responseHandler(proxy_response) {
 console.log('STATUS: ' + proxy_response.statusCode);
 console.log('HEADERS: ' + proxy_response.headers);
 proxy_response.addListener('data', function(chunkOfData) {
  //do something with a chunk of data
 });
 proxy_response.addListener('end', function() {
  //end of stream reached
 });
}

console.log("fetching imageData.txt from json.sandboxed.guru/chapter10/");
