var http = require('http');
var server = http.createServer();
server.addListener("request", requestHandler);
server.listen(8080);

function requestHandler(request, response) {
 var body = "visit http:127.0.0.1:8080/xss-exercise";
 response.statusCode = 200;
 response.setHeader("Content-Type", "text/html");
 if (request.url === "/") {
  body = '<!DOCTYPE html><html lang=en><head><meta charset=utf-8><meta http-equiv=X-UA-Compatible content="IE=edge,chrome=1"><meta name=description content><meta name=author content="Ben Smith"><meta name=viewport content="width=device-width; initial-scale=1.0"><link rel="shortcut icon" href=/favicon.ico><link rel=apple-touch-icon href=/apple-touch-icon.png><script src=js/mylibs/logTobody.js></script><style>html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{border:0;font-size:100%;font:inherit;vertical-align:baseline;margin:0;padding:0}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:none}table{border-collapse:collapse;border-spacing:0}</style><style>.Center-Container{position:relative;height:100%;box-sizing:border-box;padding:10px}.stitched{border:2px dashed #000;border-radius:10px}.Absolute-Center{width:80%;height:95%;overflow:auto;margin:auto;position:absolute;top:0;left:0;bottom:0;right:0}.Absolute-Center.is-Responsive{width:60%;height:60%;min-width:200px;max-width:400px;padding:40px}pre{padding-top:15px}</style></head><body><section class=Absolute-Center><div class="Center-Container stitched">RUN THE FOLLOWING CODE IN THE DEVELOPERS CONSOLE<pre>var   xhr= new XMLHttpRequest();\r\n\txhr=("withCredentials" in xhr)?xhr:new XDomainRequest();\r\n\txhr.open("GET","http://127.0.0.1:1337/message.json");\r\n\txhr.onload=function(){ console.log(this.responseText);};\r\n\txhr.send();</pre></div></section></body></html>';
  response.setHeader("Content-Length", Buffer.byteLength(body, 'utf8'));
  response.end(body);
 } else if (request.url === "/jsonp.html") {

 } else {

  response.end();
 }
};
console.log('Server running at http://127.0.0.1:8080/');

