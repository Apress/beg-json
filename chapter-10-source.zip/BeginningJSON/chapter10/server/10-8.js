var http = require('http');
var server = http.createServer(requestHandler);

server.listen(1337, 'localhost');

function requestHandler(request, response) {
 if (request.url === "/message.json") {

  var body = JSON.stringify({
   message : "hello-world"
  });
  response.statusCode = 200;
  var sourceOrigin = request.headers.origin;
  console.log(sourceOrigin);
  var originAllowed = (sourceOrigin === "http://json.sandboxed.guru") ? sourceOrigin : null;
  // this will only allow CORS to requests from json.sandboxed.guru NOT localhost
  response.setHeader("Access-Control-Allow-Origin", originAllowed);

  response.setHeader("Content-Type", "application/json");
  response.setHeader("Content-Length", Buffer.byteLength(body, 'utf8'));
  response.end(body);
 }
};
console.log('Server running at http://127.0.0.1:1337/');

