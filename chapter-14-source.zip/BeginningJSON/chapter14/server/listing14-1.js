//https://www.npmjs.org/package/twitter;

var util = require('util');
var twitter = require('twitter');

var twitr = new twitter({
 consumer_key : "REPLACE_WITH_YOUR_CONSUMER_KEY",
 consumer_secret : "REPLACE_WITH_YOUR_CONSUMER_KEY_SECRET",
 access_token_key : "REPLACE_WITH_YOUR_ACCESS_TOKEN",
 access_token_secret : "REPLACE_WITH_YOUR_ACCESS_TOKEN_SECRET"
});