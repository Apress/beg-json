//https://www.npmjs.org/package/twitter;

var util = require('util');
var twitter = require('twitter');
var cradle = require('../node_modules/cradle');

var twitr = new twitter({
 consumer_key : "REPLACE_WITH_YOUR_CONSUMER_KEY",
 consumer_secret : "REPLACE_WITH_YOUR_CONSUMER_KEY_SECRET",
 access_token_key : "REPLACE_WITH_YOUR_ACCESS_TOKEN",
 access_token_secret : "REPLACE_WITH_YOUR_ACCESS_TOKEN_SECRET"
});

var hashTag = "#Bendgate";

var couchDB = new (cradle.Connection)('127.0.0.1', 5984, {
 cache : true,
 raw : false,
 forceSave : true
});

var twitterDataBase = couchDB.database('twitter');

twitterDataBase.exists(function(err, exists) {
 if (err) {
  console.log('error', err);
 } else if (exists) {
  console.log('the twitter db exists');
 } else {
  console.log('twitter database does not exists.');
  twitterDataBase.create();
 }
});

twitr.stream('statuses/filter', {
 track : hashTag
}, function(stream) {
 stream.on('data', function(data) {
  twitterDataBase.save(data, function(err, res) {
   if (!err) {
    console.log(res);  //output CouchDB status
   }
  });
 });
});

