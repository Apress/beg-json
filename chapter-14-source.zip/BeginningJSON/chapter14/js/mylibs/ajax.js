var ajax = new XMLHttpRequest();
ajax.open("GET", "http://127.0.0.1:5984/twitter/_design/twitter/_view/tweets");
ajax.responseType = "json";
ajax.onload = function() {
 logAsObject(this.response);
};
ajax.send();
