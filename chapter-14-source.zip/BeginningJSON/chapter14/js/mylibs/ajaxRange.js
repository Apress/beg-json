var url = 'http://127.0.0.1:5984/twitter/_design/twitter/_view/tweets';
var lastKey = null;

function render() {
 var ajax = new XMLHttpRequest();
 console.log(lastKey);
 ajax.open("GET", incrementRange(lastKey));
 ajax.responseType = "json";
 ajax.onload = function() {
  var data = (this.response);
  var rows = data.rows;
  lastKey = rows[rows.length - 1].key;
  console.log(data);
 };
 ajax.send();
}

function incrementRange(lastCount) {
 var range = "?descending=true";
 var limit = 2;
 if (lastCount) {
  range += "&startkey=" + lastCount.toString() + "&skip=1";
 };
 range += "&limit=" + limit;
 return url + range;
};
