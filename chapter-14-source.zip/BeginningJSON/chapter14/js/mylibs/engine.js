var initialTemplateWrapper = document.getElementById("Handlebar-Tweet-Template");
var initialTemplateContent = initialTemplateWrapper.innerHTML;
var templateFunction = Handlebars.compile(initialTemplateContent);

var url = 'http://127.0.0.1:5984/twitter/_design/twitter/_view/tweets';
var lastKey = null;

function render() {
 var ajax = new XMLHttpRequest();
 console.log(lastKey);
 ajax.open("GET", incrementRange(lastKey));
 ajax.responseType = "json";
 ajax.onload = function() {
  var data = (this.response);
  var rows = data.rows;
  lastKey = rows[rows.length - 1].key;
  document.getElementById("tweets").innerHTML += templateFunction(data);
 };
 ajax.send();
}

function incrementRange(lastCount) {
 var range = "?descending=true";
 var limit = 20;
 if (lastCount) {
  range += "&startkey=" + lastCount.toString() + "&skip=1";
 };
 range += "&limit=" + limit;
 return url + range;
};

Handlebars.registerHelper('toDate', function(date) {
 return new Date(date);
});

Handlebars.registerHelper('toURL', function(text) {

 var exp = /(\b(https?):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/i;
 return text.replace(exp, "<a href='$1'>$1</a>");

});

