function setCookie(name, value, expires, path, domain, secure) {
    document.cookie = name + "=" + value
    //if expires is not null append the specified GMT date
    + ((expires) ? "; expires=" + expires.toUTCString() : "")
    //if path is not null append the specified path
    + ((path) ? "; path=" + path : "")
    //if domain is not null append the specified domain
    + ((domain) ? "; domain=" + domain : "")
    //if secure is not null provide the secure Flag to the cookie
    + ((secure) ? "; secure" : "");
};

function getCookie(name) {
    //create a pattern that matches the name of a cookie followed by the equals token and any other asii up to a semi-colon.
    var regExp = new RegExp(name + "=[^\;]*", "mgi");

    //all matches of the defined pattern are returned to an array.
    var matchingValue = (document.cookie).match(regExp);

    for (var key in matchingValue) {
        //create a temporary string that strips 'name=' from matched string;
        var replacedValue = matchingValue[key].replace(name + "=", "");
        //set the cookie value as the new value
        matchingValue[key] = replacedValue;
    }
    //return all values of the pattern found.. if any exist
    return matchingValue;
};

function destroyCookie(name) {
    setCookie(name, "null", new Date("Jan 1 1970"), null, null, null, null);
};