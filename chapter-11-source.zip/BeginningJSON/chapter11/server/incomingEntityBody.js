var http = require('http');
var server = http.createServer();
server.addListener('request', requestHandler);
server.listen(1337, '127.0.0.1');

function requestHandler(request, response) {
    console.log(request.url);

    if (request.method === "POST") {
        var incomingEntity = '';
        var data;

        request.addListener('data', function(chunk) {
            incomingEntity += chunk;
        });

        request.addListener("end", function() {
            console.log("end of stream \n");
            console.log("Raw entity: " + incomingEntity);
               
            if (request.headers['content-type'].indexOf("application/json")>-1) {
                data = JSON.parse(incomingEntity);
                if (request.url === "/formPost") {
                    response.statusCode = 200;
                    response.setHeader("Content-Type", "application/json");

                    response.setHeader("Content-Length", Buffer.byteLength(incomingEntity, 'utf8'));
                    response.end(incomingEntity);
                }
            } else if (request.headers['content-type'].indexOf("application/x-www-form-urlencoded")>-1) {
                if (request.url === "/formPost") {
                    console.log("hit");
                    response.statusCode = 200;
                    response.setHeader("Content-Type", "text/html");

                    var fname = getParamKey("fname", incomingEntity);
                    var lname = getParamKey("lname", incomingEntity);
                    var html = '<!doctype html>';
                        html += '<html lang="en">';
                        html += '<body>';
                        html += '<span>' + fname + ' ' + lname + '</span>';
                        html += '</body>';
                        html += '</html>';
                    response.setHeader("Content-Length", Buffer.byteLength(html, 'utf8'));
                    response.end(html);
                    return;
                }
            }
        });

    } else if (request.method === "GET") {
        if (request.url === "/index.html") {
            response.statusCode = 200;
            response.setHeader("Content-type", "text/html");
            response.write('<!doctype html>');
            response.write('<html lang="en">');
            response.write('<body>');
            response.write('<form action="formPost" method="POST" onsubmit="return ajax();" content="application/x-www-form-urlencoded">');
            response.write('First-Name:');
            response.write('<input name="fname" type="text" size="25"/>');
            response.write('Last-Name:');
            response.write('<input name="lname" type="text" size="25"/>');
            response.write('<input type="submit"/>');
            response.write('</form>');
            response.write('<script>');
                response.write('function ajax(){');
                response.write('var xhr = new XMLHttpRequest();');
                response.write('xhr.open("POST", "formPost");');
                response.write('xhr.setRequestHeader("Content-Type", "application/json");');
                response.write('xhr.setRequestHeader("Accept", "application/json");');
                response.write('var input = document.getElementsByTagName("input");');
                response.write('var obj = {');
                    response.write('fname : input[0].value,');
                    response.write('lname : input[1].value');
                response.write('};');
                response.write('xhr.send(JSON.stringify(obj));');
                response.write('return false;');
                response.write('}');
            response.write('</script>');
            response.write(' </body>');
            response.write('</html>');
            response.end();

        } else {
            response.statusCode = 204;
            response.end();
        }

    } 

};

function getParamKey(key, str) {
    var regExp = new RegExp(key.toLowerCase() + '=[^&]*');
    var matchingValue = (str.toLowerCase()).match(regExp);
    for (var i = 0; i < matchingValue.length; i++) {
        var replacedValue = matchingValue[i].replace(key + '=', '');
        matchingValue[i] = replacedValue;
    }
    return decodeURIComponent(matchingValue[0]);
};

var parseQueryStringToObject = function(queryString) {
    var params = {}, queries, temp, i, l;
    // Split into key/value pairs
    queries = queryString.split("&");
    // Convert the array of strings into an object
    for ( i = 0, l = queries.length; i < l; i++) {
        temp = queries[i].split('=');
        params[temp[0]] = temp[1];
    }
    
    return params;
};

console.log('Server running at http://127.0.0.1:1337/index.html');
