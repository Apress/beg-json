var http = require('http');
var server = http.createServer();
server.addListener('request', requestHandler);
server.listen(1337, '127.0.0.1');

function requestHandler(request, response) {
    console.log(request.url);
    request.setEncoding('utf8');
    response.statusCode = 200;

    response.setHeader("Access-Control-Allow-Origin", "*");
    response.setHeader("Content-Type", "text/plain");
    response.setHeader("Content-length", "5");
    response.end("hello");
};

console.log('Server running at http://127.0.0.1:1337/index.html');
